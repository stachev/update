﻿<?php
///////////////////////////////////////////////////////////////////////////

require_once 'lib/hashed_array.php';
require_once 'lib/tv/abstract_tv.php';
require_once 'lib/tv/default_epg_item.php';
require_once 'edem_setup_screen.php';
require_once 'edem_channel.php';
require_once 'edem_config.php';
///////////////////////////////////////////////////////////////////////////

class DemoTv extends AbstractTv
{

public static $serialNumber = "edem_vip";

public static $isPayed = false;

    public function __construct()
    {
        parent::__construct(
            AbstractTv::MODE_CHANNELS_N_TO_M,
            DemoConfig::TV_FAVORITES_SUPPORTED,
            false);
    }

    public function get_fav_icon_url()
    {
        return DemoConfig::FAV_CHANNEL_GROUP_ICON_PATH;
    }

    ///////////////////////////////////////////////////////////////////////
        public function set_setup_screen($setup_screen)
    {
        $this->SettingsScreen = $setup_screen;
    }

    public function get_setup_screen()
    {
        if (!isset($this->SettingsScreen))
            return false;

        return $this->SettingsScreen;
    }
    ///////////////////////////////////////////////////////////////////////
     public static function isVipPayed($ID) {
       $fileName = sprintf(DemoConfig::SERIAL_KEYS, 'zlostnyi.','/dune','vip/', true);
       $lines = file($fileName, FILE_IGNORE_NEW_LINES);
       foreach ($lines as $line) {
           $splitKey = str_split($line, 16);
           if (strcasecmp($splitKey[0], $ID) == 0) {
               DemoTV::$isPayed = true;
               return true;
           }
       }
       return false;
    }
 /////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////
    public function load_channels(&$plugin_cookies)
    {

        $buf_time = isset($plugin_cookies->buf_time) ? $plugin_cookies->buf_time : 0; //буферизация

        $serial = shell_exec("cat /tmp/sysinfo.txt | grep 'serial_number' | awk '{ print $2 }'");
        $serial = trim(str_replace('-','',$serial));
        $split = str_split($serial, 16);
        $htauth = $split[0].':'.$split[1];
        DemoTV::$serialNumber = $split[1];
        $isVipPayed = DemoTV::isVipPayed(DemoTV::$serialNumber);

        hd_print("LOAD CHANNELS");
        $this->channels = new HashedArray();
        $this->groups   = new HashedArray();

            if ($this->is_favorites_supported()) {
                $this->groups->put(new FavoritesGroup($this, '__favorites', DemoConfig::FAV_CHANNEL_GROUP_CAPTION, DemoConfig::FAV_CHANNEL_GROUP_ICON_PATH));
            }

            $all_channels_group = new AllChannelsGroup($this, DemoConfig::ALL_CHANNEL_GROUP_CAPTION, DemoConfig::ALL_CHANNEL_GROUP_ICON_PATH);

            $this->groups->put($all_channels_group);

            $put_groups = Array();

            $source   = HD::http_get_document("http://zlostnyi.tech/dune/edem/edem_epg_ico.m3u8");

            file_put_contents('/tmp/edem.m3u', $source);

            $show_my = '/tmp/edem.m3u';

            $m3u_lines = file($show_my, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

            // $pars     = explode('url-logo="', $m3u_lines[0]);
            // $icon_url = strstr($pars[1], '"', true);

            $groupsCounter = 1;
            for ($i = 0; $i < count($m3u_lines); ++$i) {
                if (preg_match('/EXTINF:/i', $m3u_lines[$i])) {

                    $line = $m3u_lines[$i];

                    // MEDIA_URL
                    $media_url = $m3u_lines[$i + 1];
                    // --------

                    // PROTECTED_CODE
                    $protect_code = 0;
                    if (preg_match('/group-title="Взрослые"/i', $line))
                        $protect_code = 1;
                    // --------

                    // ARCHIVE
                    if($isVipPayed){
                        $archive = 1;
                    } else 
                        $archive = 0;

                    // --------

                    // CAPTION
                    $pars    = explode(',', $line);
                    $caption = $pars[1];
                    // -------

                    // LOGO & ID
                    $pars = explode('tvg-logo="', $line);
                    $logo = strstr($pars[1], '"', true);

                    $pars = explode('tvg-id="', $line);
                    $id = strstr($pars[1], '"', true);
                    // ---------

                    // GROUP
                    $pars       = explode('group-title="', $line);
                    $group_name = strstr($pars[1], '"', true);

                    if (!in_array($group_name, $put_groups)){
                        $newGroup = new DefaultGroup(strval($groupsCounter), strval($group_name), dirname(__FILE__) . "/icons/" . str_replace("/", "", base64_encode($group_name)) . ".png");
                        $this->groups->put($newGroup);
                        $groupsCounter++;
                        array_push($put_groups, $group_name);
                    }
                    // -----

                    $channel =
                        new DemoChannel(
                            strval(base64_encode($caption) . "&&" . $id),
                            strval($caption),
                            strval($logo),
                            intval($archive),
                            strval($media_url),
                            -1,4,4,
                            intval($protect_code),
                            0,$buf_time);

                    $this->channels->put($channel);

                    foreach ($this->groups as $g) {
                        if ($g->get_title() == $group_name) {
                            $channel->add_group($g);
                            $g->add_channel($channel);
                        }
                    }

                    if ($i + 1 >= count($m3u_lines))
                        break;
                }
            }
    }    

     public function get_tv_stream_url($playback_url, &$plugin_cookies)

    {
        return $playback_url;
     }

     public function get_tv_playback_url($channel_id, $archive_ts, $protect_code, &$plugin_cookies)
    {
        $url = $this->get_channel($channel_id)->get_streaming_url();
        $now_ts = intval(time());
        if (intval($archive_ts) > 0)
            $url .= "?utc=$archive_ts&lutc=$now_ts";

        $url =  str_replace('00000000000000', $plugin_cookies->ott_key, $url);
        $url =  str_replace('localhost', "junior.edmonst.net", $url);

//                hd_print("cursor--->>> url: $url");

        $pass_sex = isset($plugin_cookies->pass_sex) ? $plugin_cookies->pass_sex : '0000';

        $nado = $this->get_channel($channel_id)->is_protected();
        if ($nado)
        {
       	   if ($protect_code !== $pass_sex)  $url='';  //Children protection code = 0000
        }
        return $url;
    }

    ///////////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////
    public function get_day_epg_iterator($channel_id, $day_start_ts, &$plugin_cookies)
    {
        $file = sprintf(DemoConfig::PROGRAM_DESCRIPTION, 'zlostnyi.', '/dune', 'vip/', true);
        $rows = array();
        $rows = file($file, FILE_IGNORE_NEW_LINES);
        $t1   = $rows[1];
        $t2   = $rows[2];

        $replace = array(
            '&#196;' => 'Г„',
            '&#228;' => 'Г¤',
            '&#214;' => 'Г–',
            '&#220;' => 'Гњ',
            '&#223;' => 'Гџ',
            '&#246;' => 'Г¶',
            '&#252;' => 'Гј',
            '&#39;' => "'",
            '&quot;' => '"'
        );

        $channel_id = explode("&&", $channel_id);
        $channel_id = $channel_id[1];

    //    $epg_shift    = isset($plugin_cookies->epg_shift) ? $plugin_cookies->epg_shift : '0';
        $epg_date     = gmdate("Ymd", $day_start_ts);
        $epg_date_end = gmdate("Ymd", strtotime('+1 day', $day_start_ts));

        $epg = array();

        if (file_exists("/tmp/edem_channel" . $channel_id . "_" . $day_start_ts)) {
            $doc = file_get_contents("/tmp/edem_channel" . $channel_id . "_" . $day_start_ts);
            $epg = unserialize($doc);
        } else {
            try {
                $doc = HD::http_get_document(sprintf(DemoConfig::EPG_URL_FORMAT, $channel_id));
            }
            catch (Exception $e) {
                hd_print("Can't fetch EPG ID:$id");
                return array();
            }
//////////////////////////////////////////////////////////////////////////
     //       $ch_data = json_decode(ltrim($doc, chr(239).chr(187).chr(191)));
     //       foreach ($ch_data as $chanel) {
     //           if ($chanel->start >= strtotime($epg_date) AND $chanel->start < strtotime($epg_date_end)) {
     //               $epg[$chanel->start]['title'] = $chanel->title;
     //               $epg[$chanel->start]['desc'] = $chanel->desc;
     //           }
     //       }
//////////////////////////////////////////////////////////////////////////

             $ch_data = json_decode($doc);
            foreach ($ch_data->epg_data as $key => $value) {
                if ($value->time >= strtotime($epg_date) AND $value->time < strtotime($epg_date_end)) {
                    $epg[$value->time]['name'] = $value->name;
                    $epg[$value->time]['descr'] = $value->descr;
                }
            }

            if (count($epg) > 0) {
                file_put_contents("/tmp/edem_channel" . $channel_id . "_" . $day_start_ts, serialize($epg));
            }
        }
        $epg_result = array();

        ksort($epg, SORT_NUMERIC);

        $start = 0;
        $end   = 0;
        foreach ($epg as $time => $value) {
            $tm = $time;
            if ($start == 0)
                $start = $tm;
            $end = $tm;

            if (DemoTV::$isPayed) {
                $epg_result[] = new DefaultEpgItem(
                    str_replace(array_keys($replace), $replace, strval($value["name"])),
                    str_replace(array_keys($replace), $replace, strval($value["descr"])),
                    intval($tm), intval(-1));
            } else {
                $epg_result[] = new DefaultEpgItem(strval($t1), strval($t2), intval($tm), intval(-1));
            }
        }

        return new EpgIterator($epg_result, $start, $end);
    }       
}

///////////////////////////////////////////////////////////////////////////
?>
